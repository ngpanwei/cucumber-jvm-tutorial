package ngpanwei.proposal;

public interface IProposalService {
	void createProposal(ProposalVO proposalVO);

}
