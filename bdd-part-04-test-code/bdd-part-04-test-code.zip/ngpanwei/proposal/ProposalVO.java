package ngpanwei.proposal;

public class ProposalVO {

}
